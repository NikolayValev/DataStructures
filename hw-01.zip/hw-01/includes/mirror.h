#include <string>
bool mirror(const std::string, const std::string);